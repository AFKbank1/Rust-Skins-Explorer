
// Sample data for skins
const skins = [
    { name: "Forest Hoodie", biome: "forest", price: 5 },
    { name: "Desert Pants", biome: "desert", price: 3 },
    { name: "Arctic Jacket", biome: "arctic", price: 7 },
    { name: "Jungle Helmet", biome: "jungle", price: 6 },
    { name: "Desert Boots", biome: "desert", price: 4 },
    { name: "Forest Gloves", biome: "forest", price: 2 }
];

// Search functionality
function performSearch() {
    const budget = document.getElementById("budget").value;
    const biome = document.getElementById("biome").value;
    const keyword = document.getElementById("keyword").value.toLowerCase();

    // Filter results based on criteria
    const results = skins.filter(skin => {
        const matchesBudget = budget ? skin.price <= budget : true;
        const matchesBiome = biome === "all" || skin.biome === biome;
        const matchesKeyword = keyword ? skin.name.toLowerCase().includes(keyword) : true;
        return matchesBudget && matchesBiome && matchesKeyword;
    });

    // Display results
    const resultsContainer = document.getElementById("results");
    resultsContainer.innerHTML = "";
    if (results.length === 0) {
        resultsContainer.innerHTML = "<p>No results found.</p>";
    } else {
        results.forEach(skin => {
            const item = document.createElement("div");
            item.className = "result-item";
            item.innerHTML = `<h3>${skin.name}</h3><p>Biome: ${skin.biome}</p><p>Price: $${skin.price}</p>`;
            resultsContainer.appendChild(item);
        });
    }
}
